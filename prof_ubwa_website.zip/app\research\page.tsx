import { Metadata } from "next";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";

export const metadata: Metadata = {
  title: "Research | Prof. Simon Terver Ubwa",
  description: "Explore Prof. Simon Terver Ubwa's research interests, active projects, and completed studies in Food Chemistry and Environmental Organic Chemistry.",
};

export default function ResearchPage() {
  return (
    <main className="bg-[#F8F8F8] min-h-screen py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl md:text-5xl font-bold text-[#333333] mb-12">Research</h1>
        
        <div className="mb-16">
          <h2 className="text-2xl font-bold text-[#333333] mb-6">Research Interests</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="hover:shadow-lg transition-shadow duration-300">
              <CardHeader className="bg-[#FFD700]/10 border-b">
                <CardTitle className="text-[#333333]">Food Chemistry</CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <p className="text-[#333333] mb-4">
                  Analysis of food composition, nutritional value assessment, and food safety evaluation through chemical analysis.
                </p>
                <div className="flex flex-wrap gap-2 mt-4">
                  <Badge className="bg-[#6A5ACD] hover:bg-[#6A5ACD]/80">Nutritional Analysis</Badge>
                  <Badge className="bg-[#6A5ACD] hover:bg-[#6A5ACD]/80">Food Safety</Badge>
                  <Badge className="bg-[#6A5ACD] hover:bg-[#6A5ACD]/80">Chemical Composition</Badge>
                </div>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-lg transition-shadow duration-300">
              <CardHeader className="bg-[#FFD700]/10 border-b">
                <CardTitle className="text-[#333333]">Environmental Organic Chemistry</CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <p className="text-[#333333] mb-4">
                  Study of organic pollutants in the environment, their fate, transport, and impact on ecosystems and human health.
                </p>
                <div className="flex flex-wrap gap-2 mt-4">
                  <Badge className="bg-[#6A5ACD] hover:bg-[#6A5ACD]/80">Pollutant Analysis</Badge>
                  <Badge className="bg-[#6A5ACD] hover:bg-[#6A5ACD]/80">Environmental Impact</Badge>
                  <Badge className="bg-[#6A5ACD] hover:bg-[#6A5ACD]/80">Remediation</Badge>
                </div>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-lg transition-shadow duration-300">
              <CardHeader className="bg-[#FFD700]/10 border-b">
                <CardTitle className="text-[#333333]">Sustainable Practices</CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <p className="text-[#333333] mb-4">
                  Development of sustainable methods for food production, environmental conservation, and resource utilization.
                </p>
                <div className="flex flex-wrap gap-2 mt-4">
                  <Badge className="bg-[#6A5ACD] hover:bg-[#6A5ACD]/80">Sustainable Agriculture</Badge>
                  <Badge className="bg-[#6A5ACD] hover:bg-[#6A5ACD]/80">Resource Conservation</Badge>
                  <Badge className="bg-[#6A5ACD] hover:bg-[#6A5ACD]/80">Green Chemistry</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
        
        <Tabs defaultValue="active" className="mt-12">
          <TabsList className="mb-8">
            <TabsTrigger value="active" className="text-lg">Active Projects</TabsTrigger>
            <TabsTrigger value="completed" className="text-lg">Completed Projects</TabsTrigger>
          </TabsList>
          
          <TabsContent value="active" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-[#333333]">Optimization of Nutrient Composition in Indigenous Food Products</CardTitle>
                <CardDescription>Funded by National Research Foundation | 2023-Present</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-[#333333] mb-4">
                  This project focuses on analyzing and optimizing the nutrient composition of indigenous food products to enhance their nutritional value and promote food security in local communities.
                </p>
                <h4 className="font-bold text-[#333333] mt-4 mb-2">Research Objectives:</h4>
                <ul className="list-disc pl-5 space-y-1 text-[#333333]">
                  <li>Analyze the nutrient composition of selected indigenous food products</li>
                  <li>Identify potential improvements in processing methods to preserve nutrients</li>
                  <li>Develop enhanced formulations with improved nutritional profiles</li>
                  <li>Conduct sensory evaluations to ensure acceptability of optimized products</li>
                </ul>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-[#333333]">Assessment of Heavy Metal Contamination in Agricultural Soils</CardTitle>
                <CardDescription>Collaborative Project with Environmental Protection Agency | 2022-Present</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-[#333333] mb-4">
                  This study evaluates the levels of heavy metal contamination in agricultural soils across different regions, assessing the impact on crop safety and developing mitigation strategies.
                </p>
                <h4 className="font-bold text-[#333333] mt-4 mb-2">Research Objectives:</h4>
                <ul className="list-disc pl-5 space-y-1 text-[#333333]">
                  <li>Determine heavy metal concentrations in agricultural soils from various regions</li>
                  <li>Assess bioaccumulation factors in common crops grown in contaminated soils</li>
                  <li>Evaluate potential health risks associated with consumption of affected crops</li>
                  <li>Develop remediation strategies for contaminated agricultural lands</li>
                </ul>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="completed" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-[#333333]">Development of Infant Food Formulations from Local Crops</CardTitle>
                <CardDescription>Funded by International Development Research Centre | 2019-2022</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-[#333333] mb-4">
                  This project developed nutritionally adequate infant food formulations using locally available crops to address malnutrition in resource-limited settings.
                </p>
                <h4 className="font-bold text-[#333333] mt-4 mb-2">Key Outcomes:</h4>
                <ul className="list-disc pl-5 space-y-1 text-[#333333]">
                  <li>Created three infant food formulations with optimal protein and micronutrient profiles</li>
                  <li>Conducted successful acceptability trials in target communities</li>
                  <li>Developed processing methods accessible to small-scale producers</li>
                  <li>Published findings in the International Journal of Food Science and Biotechnology</li>
                </ul>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-[#333333]">Quantitative Analysis of Antinutritional Factors in Tuber Crops</CardTitle>
                <CardDescription>University-Funded Research | 2017-2020</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-[#333333] mb-4">
                  This study quantified antinutritional factors in common tuber crops and evaluated processing methods to reduce their levels while preserving nutritional quality.
                </p>
                <h4 className="font-bold text-[#333333] mt-4 mb-2">Key Outcomes:</h4>
                <ul className="list-disc pl-5 space-y-1 text-[#333333]">
                  <li>Established baseline data on cyanogenic glycoside content in local cassava varieties</li>
                  <li>Identified optimal processing methods for reducing hydrogen cyanide levels by 95%</li>
                  <li>Developed improved storage protocols to prevent microbial contamination</li>
                  <li>Published findings in Food and Nutrition Sciences journal</li>
                </ul>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-[#333333]">Microbiological Analysis of Fermented Food Products</CardTitle>
                <CardDescription>Collaborative Research with Food Research Institute | 2015-2018</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-[#333333] mb-4">
                  This project isolated and characterized microorganisms involved in traditional food fermentation processes and assessed their potential as probiotics.
                </p>
                <h4 className="font-bold text-[#333333] mt-4 mb-2">Key Outcomes:</h4>
                <ul className="list-disc pl-5 space-y-1 text-[#333333]">
                  <li>Isolated nine microbial strains with significant roles in traditional fermentation</li>
                  <li>Characterized probiotic properties of three Lactobacillus strains</li>
                  <li>Developed starter cultures for consistent fermentation outcomes</li>
                  <li>Published findings in multiple peer-reviewed journals</li>
                </ul>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </main>
  );
}