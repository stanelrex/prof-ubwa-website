import Link from "next/link";
import { Button } from "@/components/ui/button";
import SocialLinks from "@/components/layout/social-links";
import { ExternalLink, Mail } from "lucide-react";

export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-[#333333] text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          <div>
            <h3 className="text-xl font-bold mb-4 text-[#FFD700]">Prof. Simon Terver Ubwa</h3>
            <p className="mb-4 text-white/80">
              Deputy Vice-Chancellor (Academic)<br />
              Benue State University<br />
              Makurdi, Benue State, Nigeria
            </p>
            <Button variant="outline" className="border-[#FFD700] text-[#FFD700] hover:bg-[#FFD700]/10">
              <Link href="/contact" className="flex items-center gap-2">
                Contact Me <Mail size={16} />
              </Link>
            </Button>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4 text-[#FFD700]">Quick Links</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/" className="text-white/80 hover:text-white transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-white/80 hover:text-white transition-colors">
                  About
                </Link>
              </li>
              <li>
                <Link href="/research" className="text-white/80 hover:text-white transition-colors">
                  Research
                </Link>
              </li>
              <li>
                <Link href="/publications" className="text-white/80 hover:text-white transition-colors">
                  Publications
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-white/80 hover:text-white transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4 text-[#FFD700]">Academic Profiles</h3>
            <ul className="space-y-3">
              <li>
                <Link 
                  href="https://scholar.google.com/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-white/80 hover:text-white transition-colors flex items-center gap-2"
                >
                  Google Scholar <ExternalLink size={14} />
                </Link>
              </li>
              <li>
                <Link 
                  href="https://www.academia.edu/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-white/80 hover:text-white transition-colors flex items-center gap-2"
                >
                  Academia.edu <ExternalLink size={14} />
                </Link>
              </li>
              <li>
                <Link 
                  href="https://www.adscientificindex.com/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-white/80 hover:text-white transition-colors flex items-center gap-2"
                >
                  AD Scientific Index <ExternalLink size={14} />
                </Link>
              </li>
              <li>
                <Link 
                  href="https://www.researchgate.net/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-white/80 hover:text-white transition-colors flex items-center gap-2"
                >
                  ResearchGate <ExternalLink size={14} />
                </Link>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-white/20 flex flex-col md:flex-row items-center justify-between">
          <p className="text-white/60 text-sm">
            &copy; {currentYear} Prof. Simon Terver Ubwa. All rights reserved.
          </p>
          
          <div className="mt-4 md:mt-0">
            <SocialLinks variant="light" />
          </div>
        </div>
      </div>
    </footer>
  );
}