"use client";

import { useState } from "react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, BookOpen, ExternalLink } from "lucide-react";
import Link from "next/link";
import { topPublications } from "@/lib/data";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

export default function Publications() {
  return (
    <section className="py-12" id="publications">
      <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-12">
        <div>
          <h2 className="text-3xl font-bold text-[#333333] mb-4">Notable Publications</h2>
          <p className="text-lg text-[#333333]/80 max-w-2xl">
            Highlights from Prof. Ubwa's research contributions in Food Chemistry, Environmental Chemistry, and related fields.
          </p>
        </div>
        <Button variant="ghost" className="text-[#6A5ACD] hover:text-[#6A5ACD]/80 mt-4 md:mt-0">
          <Link href="/publications" className="flex items-center gap-2">
            View All Publications <ArrowRight size={16} />
          </Link>
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {topPublications.map((publication, index) => (
          <Card 
            key={index} 
            className="hover:shadow-lg transition-shadow duration-300 flex flex-col h-full"
          >
            <CardHeader className="bg-[#FFD700]/10 border-b">
              <CardTitle className="text-lg font-bold text-[#333333]">{publication.title}</CardTitle>
            </CardHeader>
            <CardContent className="py-6 flex-grow">
              <p className="text-[#333333] mb-2"><span className="font-semibold">Journal:</span> {publication.journal}</p>
              <p className="text-[#333333]/80">{publication.summary}</p>
            </CardContent>
            <CardFooter className="border-t pt-4">
              <Button variant="outline" className="w-full border-[#6A5ACD] text-[#6A5ACD] hover:bg-[#6A5ACD]/10">
                <Link href={publication.doi} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 w-full justify-center">
                  View Article <ExternalLink size={16} />
                </Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </section>
  );
}