import './globals.css';
import type { Metadata } from 'next';
import { Inter, Roboto } from 'next/font/google';
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';

const inter = Inter({ 
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap', 
});

const roboto = Roboto({ 
  weight: ['400', '500', '700'],
  subsets: ['latin'],
  variable: '--font-roboto',
  display: 'swap', 
});

export const metadata: Metadata = {
  title: 'Prof. Simon Terver Ubwa | Academic Website',
  description: 'Official website of Prof. Simon Terver Ubwa, Deputy Vice-Chancellor (Academic) at Benue State University.',
  keywords: 'Simon Terver Ubwa, Professor, Food Chemistry, Environmental Organic Chemistry, Academic',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/favicon.ico" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      </head>
      <body className={`${inter.variable} ${roboto.variable} font-sans`}>
        <Header />
        {children}
        <Footer />
      </body>
    </html>
  );
}