"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { cn } from "@/lib/utils";
import { ChevronDown, FileText, BookOpen, Mail } from "lucide-react";

export default function Hero() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <div className="relative h-screen overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ 
          backgroundImage: "url('/prof-ubwa-new.jpg')",
        }}
      >
        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-black/60"></div>
      </div>

      {/* Content */}
      <div className="relative h-full flex items-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="max-w-3xl">
            <div 
              className={cn(
                "transition-all duration-1000 ease-out transform",
                isVisible 
                  ? "translate-y-0 opacity-100" 
                  : "translate-y-8 opacity-0"
              )}
            >
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">
                <span className="text-[#FFD700]">Prof. Simon Terver Ubwa</span>
              </h1>
              <h2 className="text-2xl md:text-3xl font-medium text-white/90 mb-4">
                Deputy Vice-Chancellor (Academic)
              </h2>
              <p className="text-xl text-white/80 mb-8 max-w-2xl">
                Specializing in Food Chemistry, Environmental Organic Chemistry, and Sustainable Practices at Benue State University.
              </p>
              
              <div className="flex flex-wrap gap-4">
                <Button 
                  className="bg-[#FFD700] text-[#333333] hover:bg-[#FFD700]/90"
                  size="lg"
                >
                  <Link href="/about" className="flex items-center gap-2">
                    About Me <FileText size={18} />
                  </Link>
                </Button>
                <Button 
                  className="bg-[#6A5ACD] hover:bg-[#6A5ACD]/90"
                  size="lg"
                >
                  <Link href="/publications" className="flex items-center gap-2">
                    Publications <BookOpen size={18} />
                  </Link>
                </Button>
                <Button
                  className="bg-[#800000] hover:bg-[#800000]/90 text-white"
                  size="lg"
                >
                  <Link href="/contact" className="flex items-center gap-2">
                    Contact <Mail size={18} />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex flex-col items-center">
        <span className="text-white/80 text-sm mb-2">Scroll Down</span>
        <ChevronDown className="text-[#FFD700] animate-bounce" size={24} />
      </div>
    </div>
  );
}