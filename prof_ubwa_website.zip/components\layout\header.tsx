"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu";
import { Menu, X } from "lucide-react";
import SocialLinks from "@/components/layout/social-links";

const navigationItems = [
  { name: "Home", href: "/" },
  { name: "About", href: "/about" },
  { name: "Research", href: "/research" },
  { name: "Publications", href: "/publications" },
  { name: "Contact", href: "/contact" },
];

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        isScrolled
          ? "bg-white shadow-md py-2"
          : "bg-[#333333]/90 backdrop-blur-sm py-4"
      )}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center">
            <span className={cn(
              "text-2xl font-bold transition-colors duration-300",
              isScrolled ? "text-[#333333]" : "text-white"
            )}>
              Prof. Simon T. Ubwa
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <NavigationMenu>
              <NavigationMenuList>
                {navigationItems.map((item) => (
                  <NavigationMenuItem key={item.name}>
                    <Link href={item.href} legacyBehavior passHref>
                      <NavigationMenuLink
                        className={cn(
                          navigationMenuTriggerStyle(),
                          "text-base font-medium bg-opacity-100",
                          isScrolled 
                            ? "bg-white text-[#333333] hover:text-[#6A5ACD] hover:bg-gray-100" 
                            : "bg-[#333333] text-white hover:text-[#FFD700] hover:bg-[#333333]",
                          pathname === item.href && (
                            isScrolled 
                              ? "text-[#6A5ACD] bg-gray-100" 
                              : "text-[#FFD700] bg-[#333333]"
                          )
                        )}
                      >
                        {item.name}
                      </NavigationMenuLink>
                    </Link>
                  </NavigationMenuItem>
                ))}
              </NavigationMenuList>
            </NavigationMenu>
            
            <div className={cn(
              "transition-opacity duration-300",
              isScrolled ? "opacity-100" : "opacity-80 hover:opacity-100"
            )}>
              <SocialLinks variant={isScrolled ? "dark" : "light"} />
            </div>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className={cn(
                "transition-colors",
                isScrolled ? "text-[#333333]" : "text-white"
              )}
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white shadow-lg">
          <nav className="flex flex-col py-4">
            {navigationItems.map((item) => (
              <Link 
                key={item.name} 
                href={item.href}
                className={cn(
                  "px-8 py-3 text-lg font-medium text-[#333333]",
                  pathname === item.href && "text-[#6A5ACD] bg-[#6A5ACD]/10"
                )}
                onClick={() => setMobileMenuOpen(false)}
              >
                {item.name}
              </Link>
            ))}
            <div className="px-8 py-4 border-t mt-2">
              <SocialLinks variant="dark" />
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}