"use client";

import { cn } from "@/lib/utils";
import Link from "next/link";
import { 
  Twitter, 
  Linkedin, 
  Mail, 
  Globe,
} from "lucide-react";

interface SocialLinksProps {
  variant?: "light" | "dark";
  size?: number;
  className?: string;
}

export default function SocialLinks({ 
  variant = "dark", 
  size = 20,
  className 
}: SocialLinksProps) {
  const socialLinks = [
    { 
      name: "Twitter", 
      href: "https://twitter.com/", 
      icon: <Twitter size={size} /> 
    },
    { 
      name: "LinkedIn", 
      href: "https://linkedin.com/in/", 
      icon: <Linkedin size={size} /> 
    },
    { 
      name: "Email", 
      href: "mailto:s.ubwa@bsu.edu.ng", 
      icon: <Mail size={size} /> 
    },
    { 
      name: "Website", 
      href: "/", 
      icon: <Globe size={size} /> 
    },
  ];

  return (
    <div className={cn("flex items-center space-x-4", className)}>
      {socialLinks.map((social) => (
        <Link 
          key={social.name} 
          href={social.href}
          target={social.name !== "Website" ? "_blank" : undefined}
          rel={social.name !== "Website" ? "noopener noreferrer" : undefined}
          aria-label={social.name}
          className={cn(
            "transition-colors duration-300",
            variant === "light" 
              ? "text-white/80 hover:text-white" 
              : "text-[#333333]/80 hover:text-[#6A5ACD]"
          )}
        >
          {social.icon}
        </Link>
      ))}
    </div>
  );
}