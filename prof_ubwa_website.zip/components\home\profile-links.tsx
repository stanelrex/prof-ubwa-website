"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { ExternalLink, BookOpen, GraduationCap, FileText, Book } from "lucide-react";

const profiles = [
  {
    name: "Google Scholar",
    description: "View citation metrics and academic papers",
    icon: <GraduationCap className="w-6 h-6" />,
    href: "https://scholar.google.com/",
    color: "bg-blue-100 text-blue-700",
  },
  {
    name: "Academia.edu",
    description: "Access full academic papers and research",
    icon: <BookOpen className="w-6 h-6" />,
    href: "https://www.academia.edu/",
    color: "bg-indigo-100 text-indigo-700",
  },
  {
    name: "AD Scientific Index",
    description: "Scientific performance and journal metrics",
    icon: <FileText className="w-6 h-6" />,
    href: "https://www.adscientificindex.com/",
    color: "bg-green-100 text-green-700",
  },
  {
    name: "ResearchGate",
    description: "Research network and publication sharing",
    icon: <Book className="w-6 h-6" />,
    href: "https://www.researchgate.net/",
    color: "bg-teal-100 text-teal-700",
  },
];

export default function ProfileLinks() {
  return (
    <section className="py-12" id="profiles">
      <h2 className="text-3xl font-bold text-[#333333] mb-4">Academic Profiles</h2>
      <p className="text-lg text-[#333333]/80 max-w-2xl mb-8">
        Connect with Prof. Ubwa on academic platforms to explore his research contributions, metrics, and collaborations.
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {profiles.map((profile) => (
          <Card key={profile.name} className="hover:shadow-lg transition-shadow duration-300">
            <CardHeader className="pb-2">
              <div className={`w-12 h-12 rounded-full ${profile.color} flex items-center justify-center mb-4`}>
                {profile.icon}
              </div>
              <CardTitle className="text-lg font-bold text-[#333333]">{profile.name}</CardTitle>
              <CardDescription>{profile.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="outline" className="w-full border-[#6A5ACD] text-[#6A5ACD] hover:bg-[#6A5ACD]/10">
                <Link href={profile.href} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 w-full justify-center">
                  Visit Profile <ExternalLink size={16} />
                </Link>
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
}