"use client";

import { useEffect, useRef } from "react";

export default function ContactMap() {
  const mapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // This is a placeholder for an actual map integration
    // In a real implementation, you would use a library like Google Maps or Leaflet
    if (mapRef.current) {
      const mapContainer = mapRef.current;
      
      // Create a simple styled div to represent the map
      mapContainer.style.backgroundColor = "#e9ecef";
      mapContainer.style.position = "relative";
      mapContainer.style.width = "100%";
      mapContainer.style.height = "100%";
      
      // Add some map-like elements
      const marker = document.createElement("div");
      marker.style.position = "absolute";
      marker.style.top = "50%";
      marker.style.left = "50%";
      marker.style.transform = "translate(-50%, -50%)";
      marker.style.width = "20px";
      marker.style.height = "20px";
      marker.style.backgroundColor = "#FFD700";
      marker.style.borderRadius = "50%";
      marker.style.border = "3px solid #333333";
      
      // Add ripple effect
      const ripple = document.createElement("div");
      ripple.style.position = "absolute";
      ripple.style.top = "50%";
      ripple.style.left = "50%";
      ripple.style.transform = "translate(-50%, -50%)";
      ripple.style.width = "40px";
      ripple.style.height = "40px";
      ripple.style.backgroundColor = "transparent";
      ripple.style.borderRadius = "50%";
      ripple.style.border = "3px solid #FFD700";
      ripple.style.opacity = "0.6";
      ripple.style.animation = "ripple 1.5s infinite";
      
      // Add labels
      const label = document.createElement("div");
      label.style.position = "absolute";
      label.style.bottom = "10px";
      label.style.left = "10px";
      label.style.padding = "8px 12px";
      label.style.backgroundColor = "#333333";
      label.style.color = "white";
      label.style.fontSize = "14px";
      label.style.borderRadius = "4px";
      label.innerText = "Benue State University, Makurdi";
      
      // Add the keyframes for the ripple animation
      const style = document.createElement("style");
      style.innerHTML = `
        @keyframes ripple {
          0% {
            width: 20px;
            height: 20px;
            opacity: 0.6;
          }
          100% {
            width: 60px;
            height: 60px;
            opacity: 0;
          }
        }
      `;
      document.head.appendChild(style);
      
      // Add all elements to the map
      mapContainer.appendChild(ripple);
      mapContainer.appendChild(marker);
      mapContainer.appendChild(label);
      
      // Add grid lines to simulate a map
      for (let i = 0; i < 10; i++) {
        const horizontalLine = document.createElement("div");
        horizontalLine.style.position = "absolute";
        horizontalLine.style.left = "0";
        horizontalLine.style.right = "0";
        horizontalLine.style.top = `${i * 10}%`;
        horizontalLine.style.height = "1px";
        horizontalLine.style.backgroundColor = "rgba(0,0,0,0.1)";
        
        const verticalLine = document.createElement("div");
        verticalLine.style.position = "absolute";
        verticalLine.style.top = "0";
        verticalLine.style.bottom = "0";
        verticalLine.style.left = `${i * 10}%`;
        verticalLine.style.width = "1px";
        verticalLine.style.backgroundColor = "rgba(0,0,0,0.1)";
        
        mapContainer.appendChild(horizontalLine);
        mapContainer.appendChild(verticalLine);
      }
    }
  }, []);

  return <div ref={mapRef} className="w-full h-full"></div>;
}