import Hero from "@/components/home/hero";
import Publications from "@/components/home/publications";
import Research from "@/components/home/research";
import ProfileLinks from "@/components/home/profile-links";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Prof. Simon Terver Ubwa | Deputy Vice-Chancellor (Academic)",
  description: "Official website of Prof. Simon Terver Ubwa, Deputy Vice-Chancellor (Academic) at Benue State University. Specializing in Food Chemistry and Environmental Organic Chemistry.",
  keywords: "Simon Terver Ubwa, Professor, Deputy Vice-Chancellor, Benue State University, Food Chemistry, Environmental Organic Chemistry",
};

export default function Home() {
  return (
    <main className="min-h-screen bg-[#F8F8F8]">
      <Hero />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-24">
        <Research />
        <Publications />
        <ProfileLinks />
      </div>
    </main>
  );
}