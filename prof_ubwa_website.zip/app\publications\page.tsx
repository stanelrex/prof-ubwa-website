import { Metadata } from "next";
import { publications } from "@/lib/data";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ExternalLink } from "lucide-react";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Publications | Prof. Simon Terver Ubwa",
  description: "Explore Prof. Simon Terver Ubwa's academic publications in Food Chemistry, Environmental Organic Chemistry, and Sustainable Practices.",
};

export default function PublicationsPage() {
  return (
    <main className="bg-[#F8F8F8] min-h-screen py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-12">
          <div>
            <h1 className="text-4xl md:text-5xl font-bold text-[#333333] mb-4">Publications</h1>
            <p className="text-lg text-[#333333]/80 max-w-2xl">
              A collection of peer-reviewed articles, conference papers, and book chapters published by Prof. Simon Terver Ubwa.
            </p>
          </div>
          
          <div className="mt-6 md:mt-0 flex flex-wrap gap-4">
            <Button className="bg-[#6A5ACD] hover:bg-[#6A5ACD]/80">
              <Link href="https://scholar.google.com/" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2">
                Google Scholar <ExternalLink size={16} />
              </Link>
            </Button>
            <Button className="bg-[#6A5ACD] hover:bg-[#6A5ACD]/80">
              <Link href="https://www.academia.edu/" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2">
                Academia.edu <ExternalLink size={16} />
              </Link>
            </Button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 gap-8">
          {publications.map((publication, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow duration-300">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <CardTitle className="text-xl font-bold text-[#333333]">{publication.title}</CardTitle>
                  <Badge className="bg-[#FFD700] text-[#333333] hover:bg-[#FFD700]/80">
                    {publication.year}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <p className="text-[#333333]"><span className="font-semibold">Authors:</span> {publication.authors}</p>
                  <p className="text-[#333333]"><span className="font-semibold">Journal:</span> {publication.journal}</p>
                  {publication.abstract && (
                    <div>
                      <p className="font-semibold text-[#333333]">Abstract:</p>
                      <p className="text-[#333333]/80 mt-2">{publication.abstract}</p>
                    </div>
                  )}
                  <div className="flex flex-wrap gap-2 pt-2">
                    {publication.keywords.map((keyword, idx) => (
                      <Badge key={idx} variant="outline" className="text-[#333333] border-[#6A5ACD]">
                        {keyword}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
              <CardFooter className="border-t pt-6 flex flex-wrap gap-4">
                {publication.doi && (
                  <Button variant="outline" className="border-[#6A5ACD] text-[#6A5ACD] hover:bg-[#6A5ACD]/10">
                    <Link href={publication.doi} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2">
                      View Article <ExternalLink size={16} />
                    </Link>
                  </Button>
                )}
                {publication.citations && (
                  <div className="flex items-center gap-2 text-[#333333]">
                    <span className="font-semibold">Citations:</span> {publication.citations}
                  </div>
                )}
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </main>
  );
}