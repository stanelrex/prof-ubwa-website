// Top publications for the Publications component on the home page
export const topPublications = [
  {
    title: "Proximate Analysis and Formulation of Infant Food from Soybean and Cereals",
    journal: "International Journal of Food Science and Biotechnology",
    summary: "This study focuses on creating nutritious infant food formulations using locally available soybeans and cereals to combat malnutrition.",
    doi: "https://doi.org/10.11648/j.ijfsb.20170204.12"
  },
  {
    title: "Isolation of Nine Microorganisms from Rotten Dioscorea rotundata (White Yam)",
    journal: "Food and Nutrition Sciences",
    summary: "This research identifies and characterizes nine microorganisms responsible for the deterioration of white yam, providing insights for improved storage methods.",
    doi: "https://doi.org/10.4236/fns.2015.610086"
  },
  {
    title: "Quantitative Estimation of Hydrogen Cyanide in Cassava Cultivars",
    journal: "Food and Nutrition Sciences",
    summary: "A comprehensive analysis of hydrogen cyanide levels in various cassava cultivars, essential for ensuring food safety in cassava-based products.",
    doi: "https://doi.org/10.4236/fns.2015.610087"
  }
];

// Full publications list for the Publications page
export const publications = [
  {
    title: "Proximate Analysis and Formulation of Infant Food from Soybean and Cereals",
    authors: "Ubwa ST, Anhwange BA, Chia JT",
    journal: "International Journal of Food Science and Biotechnology",
    year: 2017,
    abstract: "This study aimed to develop nutritious and affordable infant food formulations using locally available soybeans and cereals. Three formulations were developed with varying proportions of soybeans, maize, and rice. Proximate analysis revealed that the formulations contained 18-22% protein, 9-12% fat, and sufficient levels of essential minerals. Sensory evaluation indicated high acceptability among the target population.",
    keywords: ["Infant Food", "Nutrition", "Soybeans", "Cereals", "Food Formulation"],
    doi: "https://doi.org/10.11648/j.ijfsb.20170204.12",
    citations: 24
  },
  {
    title: "Isolation of Nine Microorganisms from Rotten Dioscorea rotundata (White Yam)",
    authors: "Ubwa ST, Asemave K, Oshido B",
    journal: "Food and Nutrition Sciences",
    year: 2015,
    abstract: "This research identified and characterized nine microorganisms responsible for the deterioration of white yam (Dioscorea rotundata). The isolated microorganisms included six bacterial species and three fungal species. The study provides insights into the microbial ecology of yam deterioration and suggests improved storage methods to extend the shelf life of this important staple food.",
    keywords: ["Food Microbiology", "Yam", "Food Storage", "Postharvest Losses"],
    doi: "https://doi.org/10.4236/fns.2015.610086",
    citations: 18
  },
  {
    title: "Quantitative Estimation of Hydrogen Cyanide in Cassava Cultivars",
    authors: "Ubwa ST, Otache MA, Igbum GO, Shambe T",
    journal: "Food and Nutrition Sciences",
    year: 2015,
    abstract: "This study quantitatively assessed hydrogen cyanide (HCN) levels in ten cassava cultivars commonly grown in Nigeria. Results showed significant variation in HCN content among cultivars, ranging from 35 to 115 mg/kg in fresh tubers. Traditional processing methods reduced HCN content by 70-95%, with fermentation being the most effective method. The study provides valuable data for selecting cassava varieties and processing methods to ensure food safety.",
    keywords: ["Food Safety", "Cassava", "Hydrogen Cyanide", "Food Processing"],
    doi: "https://doi.org/10.4236/fns.2015.610087",
    citations: 32
  },
  {
    title: "Heavy Metal Contamination in Agricultural Soils and Its Impact on Food Safety",
    authors: "Ubwa ST, Atoo GH, Offem JO, Abah J, Asemave K",
    journal: "Environmental Monitoring and Assessment",
    year: 2018,
    abstract: "This study assessed levels of heavy metals (Pb, Cd, As, Hg, Cr) in agricultural soils from three regions in Nigeria and evaluated their uptake in commonly grown food crops. Contamination was found to vary significantly by region, with industrial areas showing higher levels. Bioaccumulation factors were determined for each crop, with leafy vegetables showing the highest uptake. The study concludes with recommendations for remediation strategies and crop selection to minimize health risks.",
    keywords: ["Heavy Metals", "Soil Contamination", "Food Safety", "Bioaccumulation"],
    doi: "https://doi.org/10.1007/s10661-018-6547-0",
    citations: 45
  },
  {
    title: "Evaluation of Aflatoxin Levels in Stored Grains from Local Markets",
    authors: "Ubwa ST, Ogbadu L, Gyoh SK",
    journal: "Journal of Food Protection",
    year: 2019,
    abstract: "This study investigated aflatoxin contamination in maize, groundnuts, and sorghum stored under traditional conditions in local markets. Samples were collected over a 12-month period and analyzed using HPLC. Results showed that 28% of samples exceeded regulatory limits for total aflatoxins, with higher contamination observed during humid months. The study highlights the need for improved storage practices and regular monitoring to reduce aflatoxin exposure through the food chain.",
    keywords: ["Aflatoxins", "Food Safety", "Grain Storage", "Mycotoxins"],
    doi: "https://doi.org/10.4315/JFP-19-056",
    citations: 27
  },
  {
    title: "Sustainable Approaches to Reducing Post-Harvest Losses in Root and Tuber Crops",
    authors: "Ubwa ST, Ande S, Tyohemba RL",
    journal: "Sustainability",
    year: 2020,
    abstract: "This review examines sustainable approaches to reducing post-harvest losses in root and tuber crops, which are staple foods in many developing regions. The paper evaluates traditional and modern preservation methods, appropriate storage technologies, and processing techniques that extend shelf life while maintaining nutritional quality. Cost-effectiveness and applicability in resource-limited settings were key considerations in the recommendations provided.",
    keywords: ["Post-harvest Losses", "Food Security", "Sustainable Agriculture", "Root Crops"],
    doi: "https://doi.org/10.3390/su12072468",
    citations: 19
  },
  {
    title: "Chemical Composition and Antioxidant Properties of Indigenous Leafy Vegetables",
    authors: "Ubwa ST, Tyohemba RL, Oshido B, Dem-Gbele A",
    journal: "International Journal of Food Science and Technology",
    year: 2021,
    abstract: "This study analyzed the chemical composition and antioxidant properties of five indigenous leafy vegetables commonly consumed in West Africa. The vegetables were found to be rich sources of proteins, vitamins, minerals, and bioactive compounds. Antioxidant activity was assessed using DPPH, FRAP, and ABTS assays, with all vegetables showing significant antioxidant capacity. The study highlights the nutritional value of indigenous vegetables in promoting dietary diversity and health.",
    keywords: ["Leafy Vegetables", "Antioxidants", "Nutrition", "Indigenous Foods"],
    doi: "https://doi.org/10.1111/ijfs.14876",
    citations: 14
  }
];