"use client";

import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, FlaskRound as Flask, Leaf, Microscope } from "lucide-react";
import Link from "next/link";

const researchAreas = [
  {
    title: "Food Chemistry",
    description: "Analysis of food composition, nutritional value, and safety through chemical approaches.",
    icon: <Flask className="w-12 h-12 text-[#FFD700]" />,
  },
  {
    title: "Environmental Organic Chemistry",
    description: "Study of organic pollutants in the environment, their fate, transport, and impact on ecosystems.",
    icon: <Leaf className="w-12 h-12 text-[#FFD700]" />,
  },
  {
    title: "Sustainable Practices",
    description: "Development of sustainable methods for food production and environmental conservation.",
    icon: <Microscope className="w-12 h-12 text-[#FFD700]" />,
  },
];

export default function Research() {
  return (
    <section className="py-12" id="research">
      <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-12">
        <div>
          <h2 className="text-3xl font-bold text-[#333333] mb-4">Research Interests</h2>
          <p className="text-lg text-[#333333]/80 max-w-2xl">
            Prof. Ubwa's research focuses on addressing challenges in food safety, environmental protection, and sustainable development.
          </p>
        </div>
        <Button variant="ghost" className="text-[#6A5ACD] hover:text-[#6A5ACD]/80 mt-4 md:mt-0">
          <Link href="/research" className="flex items-center gap-2">
            Explore Research <ArrowRight size={16} />
          </Link>
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {researchAreas.map((area, index) => (
          <Card key={index} className="hover:shadow-lg transition-shadow duration-300">
            <CardHeader className="pb-4">
              <div className="mb-4">{area.icon}</div>
              <CardTitle className="text-xl font-bold text-[#333333]">{area.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-[#333333]/80">{area.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
}