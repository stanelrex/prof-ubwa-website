import { Metadata } from "next";
import Image from "next/image";
import { Card, CardContent } from "@/components/ui/card";

export const metadata: Metadata = {
  title: "About | Prof. Simon Terver Ubwa",
  description: "Learn about Prof. Simon Terver Ubwa's academic background, research interests, and professional experience.",
};

export default function AboutPage() {
  return (
    <main className="bg-[#F8F8F8] min-h-screen py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <div className="sticky top-24">
              <div className="relative h-[400px] w-full rounded-lg overflow-hidden shadow-lg mb-6">
                <Image 
                  src="/prof-ubwa-new.jpg" 
                  alt="Prof. Simon Terver Ubwa" 
                  fill 
                  className="object-cover"
                />
              </div>
              
              <Card>
                <CardContent className="pt-6">
                  <h3 className="font-bold text-xl mb-4 text-[#333333]">Current Position</h3>
                  <p className="text-[#333333]">Deputy Vice-Chancellor (Academic)</p>
                  <p className="text-[#333333]">Benue State University</p>
                  
                  <h3 className="font-bold text-xl mt-6 mb-4 text-[#333333]">Specialization</h3>
                  <ul className="space-y-2">
                    <li className="text-[#333333]">Food Chemistry</li>
                    <li className="text-[#333333]">Environmental Organic Chemistry</li>
                    <li className="text-[#333333]">Sustainable Practices</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
          
          <div className="lg:col-span-2 space-y-8">
            <h1 className="text-4xl md:text-5xl font-bold text-[#333333] mb-6">Biography</h1>
            
            <div className="prose max-w-none text-[#333333]">
              <p className="text-lg leading-relaxed mb-6">
                Professor Simon Terver Ubwa is a distinguished academic and researcher currently serving as the Deputy Vice-Chancellor (Academic) at Benue State University. With over two decades of experience in academia, Prof. Ubwa has made significant contributions to the fields of Food Chemistry and Environmental Organic Chemistry.
              </p>
              
              <p className="text-lg leading-relaxed mb-6">
                His research focuses on sustainable food practices, chemical analysis of food products, and environmental contamination assessment. Prof. Ubwa's work has been published in numerous peer-reviewed journals and has influenced policy decisions in food safety and environmental protection.
              </p>
              
              <h2 className="text-2xl font-bold mt-10 mb-4">Academic Background</h2>
              
              <p className="text-lg leading-relaxed mb-6">
                Prof. Ubwa holds a PhD in Analytical Chemistry from the University of Ibadan, with a specialization in Food and Environmental Chemistry. His academic journey began with a Bachelor's degree in Chemistry, followed by a Master's degree in Analytical Chemistry, both from Benue State University.
              </p>
              
              <h2 className="text-2xl font-bold mt-10 mb-4">Research Impact</h2>
              
              <p className="text-lg leading-relaxed mb-6">
                His groundbreaking research on quantitative estimation of hydrogen cyanide in cassava cultivars has provided valuable insights into food safety measures for cassava-based products. Additionally, his work on microorganisms in rotten yams has contributed to improved storage techniques for tuber crops in tropical regions.
              </p>
              
              <p className="text-lg leading-relaxed mb-6">
                Prof. Ubwa's recent research on infant food formulation from soybean and cereals has addressed nutritional challenges in developing regions, providing affordable and nutritious alternatives for infant feeding.
              </p>
              
              <h2 className="text-2xl font-bold mt-10 mb-4">Academic Leadership</h2>
              
              <p className="text-lg leading-relaxed mb-6">
                As Deputy Vice-Chancellor (Academic), Prof. Ubwa oversees academic policies, curriculum development, and quality assurance at Benue State University. His leadership has fostered innovation in teaching methodologies and research excellence across various departments.
              </p>
              
              <p className="text-lg leading-relaxed mb-6">
                Prof. Ubwa actively mentors young researchers and has supervised numerous PhD and Master's students who have gone on to make significant contributions in their respective fields. His commitment to academic excellence and research integrity continues to inspire the next generation of scientists.
              </p>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}