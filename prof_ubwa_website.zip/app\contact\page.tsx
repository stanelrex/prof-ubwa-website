import { Metadata } from "next";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Mail, MapPin, Clock, Phone } from "lucide-react";
import ContactMap from "@/components/contact/contact-map";
import SocialLinks from "@/components/contact/social-links";

export const metadata: Metadata = {
  title: "Contact | Prof. Simon Terver Ubwa",
  description: "Get in touch with Prof. Simon Terver Ubwa. Find contact information, office location, and office hours.",
};

export default function ContactPage() {
  return (
    <main className="bg-[#F8F8F8] min-h-screen py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl md:text-5xl font-bold text-[#333333] mb-12">Contact</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl text-[#333333]">Send a Message</CardTitle>
              </CardHeader>
              <CardContent>
                <form className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="name">Name</Label>
                    <Input 
                      id="name" 
                      placeholder="Your Name" 
                      className="border-[#6A5ACD]/30 focus-visible:ring-[#6A5ACD]"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input 
                      id="email" 
                      type="email" 
                      placeholder="Your Email" 
                      className="border-[#6A5ACD]/30 focus-visible:ring-[#6A5ACD]"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="subject">Subject</Label>
                    <Input 
                      id="subject" 
                      placeholder="Message Subject" 
                      className="border-[#6A5ACD]/30 focus-visible:ring-[#6A5ACD]"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="message">Message</Label>
                    <Textarea 
                      id="message" 
                      placeholder="Your Message" 
                      rows={6}
                      className="border-[#6A5ACD]/30 focus-visible:ring-[#6A5ACD]"
                    />
                  </div>
                  
                  <Button className="w-full bg-[#228B22] hover:bg-[#228B22]/90">
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
          
          <div className="space-y-8">
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <MapPin className="text-[#FFD700] mt-1" />
                    <div>
                      <h3 className="font-bold text-lg text-[#333333]">Office Location</h3>
                      <p className="text-[#333333]">Office of the Deputy Vice-Chancellor (Academic)</p>
                      <p className="text-[#333333]">Administration Block, 2nd Floor</p>
                      <p className="text-[#333333]">Benue State University</p>
                      <p className="text-[#333333]">Makurdi, Benue State, Nigeria</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-4">
                    <Clock className="text-[#FFD700] mt-1" />
                    <div>
                      <h3 className="font-bold text-lg text-[#333333]">Office Hours</h3>
                      <p className="text-[#333333]">Monday - Friday: 9:00 AM - 4:00 PM</p>
                      <p className="text-[#333333]">Saturday - Sunday: Closed</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-4">
                    <Phone className="text-[#FFD700] mt-1" />
                    <div>
                      <h3 className="font-bold text-lg text-[#333333]">Phone</h3>
                      <p className="text-[#333333]">+234 (0) 123 456 7890</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-4">
                    <Mail className="text-[#FFD700] mt-1" />
                    <div>
                      <h3 className="font-bold text-lg text-[#333333]">Email</h3>
                      <p className="text-[#333333]">s.ubwa@bsu.edu.ng</p>
                      <p className="text-[#333333]">simonubwa@gmail.com</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <div className="h-[300px] rounded-lg overflow-hidden shadow-md">
              <ContactMap />
            </div>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-xl text-[#333333]">Connect Online</CardTitle>
              </CardHeader>
              <CardContent>
                <SocialLinks />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </main>
  );
}