"use client";

import { cn } from "@/lib/utils";
import Link from "next/link";
import { 
  Twitter, 
  Linkedin, 
  Mail, 
  Globe,
  BookOpen,
  GraduationCap
} from "lucide-react";

interface SocialLinksProps {
  variant?: "light" | "dark";
  size?: number;
  className?: string;
  showLabels?: boolean;
}

export default function SocialLinks({ 
  variant = "dark", 
  size = 20,
  className,
  showLabels = false
}: SocialLinksProps) {
  const socialLinks = [
    { 
      name: "Twitter", 
      href: "https://twitter.com/", 
      icon: <Twitter size={size} /> 
    },
    { 
      name: "LinkedIn", 
      href: "https://linkedin.com/in/", 
      icon: <Linkedin size={size} /> 
    },
    { 
      name: "Google Scholar", 
      href: "https://scholar.google.com/", 
      icon: <GraduationCap size={size} /> 
    },
    { 
      name: "ResearchGate", 
      href: "https://www.researchgate.net/", 
      icon: <BookOpen size={size} /> 
    },
    { 
      name: "Email", 
      href: "mailto:s.ubwa@bsu.edu.ng", 
      icon: <Mail size={size} /> 
    },
  ];

  return (
    <div className={cn(
      "flex items-center gap-6",
      showLabels ? "flex-col items-start" : "flex-row", 
      className
    )}>
      {socialLinks.map((social) => (
        <Link 
          key={social.name} 
          href={social.href}
          target={social.name !== "Website" ? "_blank" : undefined}
          rel={social.name !== "Website" ? "noopener noreferrer" : undefined}
          aria-label={social.name}
          className={cn(
            "transition-colors duration-300",
            showLabels ? "flex items-center gap-3" : "",
            variant === "light" 
              ? "text-white/80 hover:text-white" 
              : "text-[#333333]/80 hover:text-[#6A5ACD]"
          )}
        >
          {social.icon}
          {showLabels && (
            <span className={cn(
              variant === "light" ? "text-white/80" : "text-[#333333]/80"
            )}>
              {social.name}
            </span>
          )}
        </Link>
      ))}
    </div>
  );
}